# JWT 시크릿 키 (사용자 정의)
SECRET_KEY = "your_secret_key"

# JWT 만료 시간 (예: 1시간)
ACCESS_TOKEN_EXPIRE_MINUTES = 540