from sqlalchemy import create_engine

db_config = {
    "host": "changsoft1.iptime.org",
    "port": 18800,
    "user": "changsoft",
    "password": "chang2008!",
    "database": "structure3",
}

# 창소프트 DB(structure3)에 연결
def create_db_connection():
    db_name = db_config["database"]
    db_url = f"mysql+pymysql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}"
    engine = create_engine(db_url)

    try:
        connection = engine.connect()
        if connection:
          print(f"Successfully connected to database {db_name}")
          return engine
        else:
          print("Failed to create connection")
          exit()
    except Exception as e:
        print(f"An error occurred when trying to connect to database {db_name}: {str(e)}")
        exit()

