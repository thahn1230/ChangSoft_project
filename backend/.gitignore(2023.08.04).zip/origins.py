origins = [
    "*",  # wildcard
    # "http://192.168.0.133"
    # "http://localhost.tiangolo.com",
    # "https://localhost.tiangolo.com",
    # "http://localhost",
    # "http://localhost:3000",
]
